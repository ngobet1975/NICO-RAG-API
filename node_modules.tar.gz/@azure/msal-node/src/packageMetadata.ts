/* eslint-disable header/header */
export const name = "@azure/msal-node";
export const version = "2.16.3";
