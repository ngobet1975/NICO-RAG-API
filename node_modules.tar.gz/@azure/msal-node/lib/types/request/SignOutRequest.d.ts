import { AccountInfo } from "@azure/msal-common/node";
/** @public */
export type SignOutRequest = {
    account: AccountInfo;
    correlationId?: string;
};
//# sourceMappingURL=SignOutRequest.d.ts.map