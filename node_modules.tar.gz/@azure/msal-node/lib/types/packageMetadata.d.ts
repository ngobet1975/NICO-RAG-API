export declare const name = "@azure/msal-node";
export declare const version = "2.16.3";
//# sourceMappingURL=packageMetadata.d.ts.map