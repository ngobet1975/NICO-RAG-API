export declare const missingKidError = "missing_kid_error";
export declare const missingAlgError = "missing_alg_error";
//# sourceMappingURL=JoseHeaderErrorCodes.d.ts.map