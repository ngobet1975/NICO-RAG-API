export declare const cacheQuotaExceeded = "cache_quota_exceeded";
export declare const cacheErrorUnknown = "cache_error_unknown";
//# sourceMappingURL=CacheErrorCodes.d.ts.map