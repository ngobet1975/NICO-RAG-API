/**
 * AuthErrorMessage class containing string constants used by error codes and messages.
 */
export declare const unexpectedError = "unexpected_error";
export declare const postRequestFailed = "post_request_failed";
//# sourceMappingURL=AuthErrorCodes.d.ts.map