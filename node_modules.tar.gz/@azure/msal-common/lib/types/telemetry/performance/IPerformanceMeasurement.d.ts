export interface IPerformanceMeasurement {
    startMeasurement(): void;
    endMeasurement(): void;
    flushMeasurement(): number | null;
}
//# sourceMappingURL=IPerformanceMeasurement.d.ts.map