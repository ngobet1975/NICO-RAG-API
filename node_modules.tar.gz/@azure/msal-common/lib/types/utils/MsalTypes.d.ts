/**
 * Key-Value type to support queryParams, extraQueryParams and claims
 */
export type StringDict = {
    [key: string]: string;
};
//# sourceMappingURL=MsalTypes.d.ts.map