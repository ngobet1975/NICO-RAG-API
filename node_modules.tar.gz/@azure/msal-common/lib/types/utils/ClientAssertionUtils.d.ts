import { ClientAssertionCallback } from "../account/ClientCredentials.js";
export declare function getClientAssertion(clientAssertion: string | ClientAssertionCallback, clientId: string, tokenEndpoint?: string): Promise<string>;
//# sourceMappingURL=ClientAssertionUtils.d.ts.map