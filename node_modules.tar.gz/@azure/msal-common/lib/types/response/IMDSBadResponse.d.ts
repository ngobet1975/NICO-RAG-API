export type IMDSBadResponse = {
    error: string;
    "newest-versions": Array<string>;
};
//# sourceMappingURL=IMDSBadResponse.d.ts.map