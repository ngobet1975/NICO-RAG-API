export interface IGuidGenerator {
    generateGuid(): string;
    isGuid(guid: string): boolean;
}
//# sourceMappingURL=IGuidGenerator.d.ts.map