export type ThrottlingEntity = {
    throttleTime: number;
    error?: string;
    errorCodes?: Array<string>;
    errorMessage?: string;
    subError?: string;
};
//# sourceMappingURL=ThrottlingEntity.d.ts.map