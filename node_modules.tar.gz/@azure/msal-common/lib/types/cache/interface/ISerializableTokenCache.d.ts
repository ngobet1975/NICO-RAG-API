export interface ISerializableTokenCache {
    deserialize: (cache: string) => void;
    serialize: () => string;
}
//# sourceMappingURL=ISerializableTokenCache.d.ts.map