import { AzureRegion } from "./AzureRegion.js";
export type AzureRegionConfiguration = {
    azureRegion?: AzureRegion;
    environmentRegion: string | undefined;
};
//# sourceMappingURL=AzureRegionConfiguration.d.ts.map