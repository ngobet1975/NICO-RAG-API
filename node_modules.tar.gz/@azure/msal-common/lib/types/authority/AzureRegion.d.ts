export type AzureRegion = string;
//# sourceMappingURL=AzureRegion.d.ts.map