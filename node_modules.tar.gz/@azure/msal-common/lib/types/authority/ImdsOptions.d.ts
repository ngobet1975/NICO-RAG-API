export type ImdsOptions = {
    headers?: {
        Metadata: string;
    };
};
//# sourceMappingURL=ImdsOptions.d.ts.map