import { RegionDiscoveryOutcomes, RegionDiscoverySources } from "../utils/Constants.js";
export type RegionDiscoveryMetadata = {
    region_used?: string;
    region_source?: RegionDiscoverySources;
    region_outcome?: RegionDiscoveryOutcomes;
};
//# sourceMappingURL=RegionDiscoveryMetadata.d.ts.map