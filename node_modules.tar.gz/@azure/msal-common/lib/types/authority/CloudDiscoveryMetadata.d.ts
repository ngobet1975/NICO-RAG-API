export type CloudDiscoveryMetadata = {
    preferred_network: string;
    preferred_cache: string;
    aliases: Array<string>;
};
//# sourceMappingURL=CloudDiscoveryMetadata.d.ts.map