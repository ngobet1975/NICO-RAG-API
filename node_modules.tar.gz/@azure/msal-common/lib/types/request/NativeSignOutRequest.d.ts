export type NativeSignOutRequest = {
    clientId: string;
    accountId: string;
    correlationId: string;
};
//# sourceMappingURL=NativeSignOutRequest.d.ts.map