export declare const name = "@azure/msal-common";
export declare const version = "14.16.1";
//# sourceMappingURL=packageMetadata.d.ts.map