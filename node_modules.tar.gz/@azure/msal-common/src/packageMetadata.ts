/* eslint-disable header/header */
export const name = "@azure/msal-common";
export const version = "14.16.1";
